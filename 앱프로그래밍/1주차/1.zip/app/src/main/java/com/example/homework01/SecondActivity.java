package com.example.homework01;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {
    TextView tvArr;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second_activity);
        tvArr = findViewById(R.id.tvArr);

        Intent intent = getIntent();
        int num = intent.getIntExtra("num", 0);
        tvArr.setText("전달 받은 값 : " + num);
    }

    public void onClick(View v){
        switch (v.getId()){
            case R.id.btnReturn:
                getReturn();
                break;

            case R.id.btnFin:
                finish();
                break;
        }
    }

    public void getReturn(){
        Intent intent = getIntent();
        int iNum = intent.getIntExtra("num", 0);
        int iResult = iNum * iNum;

        Intent intent1 = new Intent(getApplicationContext(), MainActivity.class);
        intent1.putExtra("result", iResult);
        setResult(RESULT_OK, intent1);
        finish();
    }
}
