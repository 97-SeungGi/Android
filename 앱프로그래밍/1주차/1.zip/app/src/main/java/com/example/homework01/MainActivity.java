package com.example.homework01;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText edtNum1;
    TextView tvRet;
    Button btnCall;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtNum1 = findViewById(R.id.edtNum1);
        tvRet = findViewById(R.id.tvRet);
        btnCall = findViewById(R.id.btnCall);

        btnCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getReturn();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        int iResult = data.getIntExtra("result", 0);
        tvRet.setText(iResult + "입니다.");
    }

    public void getReturn(){
        int num = Integer.parseInt(edtNum1.getText().toString());
        Intent intent = new Intent(getApplicationContext(), SecondActivity.class);
        intent.putExtra("num", num);
        startActivityForResult(intent, 0);
    }
}