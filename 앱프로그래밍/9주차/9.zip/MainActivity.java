package com.example.bluetoothsample;

import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothAdapter;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {
    private static final int ACTION_REQUEST_ENABLE = 1;

    // 반환되는 인텐트 정보 출력을 위한 문자열
    public static String EXTRA_DEVICE_ADDRESS = "device address";

    // 블루투스 장치 어뎁터
    private BluetoothAdapter mBtAdapter;

    // 장치 관리 목록 리스트
    private ArrayAdapter<String> mNewDeviceArrayAdapter;
    private ArrayAdapter<String> pairedDeviceArrayAdapter;

    // 리스트 뷰 멤버
    ListView newDeviceListView;
    ListView pairedListView;

    // 필요 위젯 변수
    private Button scanButton = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        scanButton = findViewById(R.id.button_scan);

        scanButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 검색 기능 수행
            }
        });

        // ArrayAdapter 초기화
        pairedDeviceArrayAdapter = new ArrayAdapter<String>(this, R.layout.device_name);
        mNewDeviceArrayAdapter = new ArrayAdapter<String>(this, R.layout.device_name);

        // 리스트 뷰
        pairedListView = findViewById(R.id.paired_devices);
        pairedListView.setAdapter(pairedDeviceArrayAdapter);

        newDeviceListView = findViewById(R.id.new_devices);
        newDeviceListView.setAdapter(mNewDeviceArrayAdapter);
    }

   @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}
