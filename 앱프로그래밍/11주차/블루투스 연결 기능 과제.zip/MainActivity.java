package com.example.bluetoothsample;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Set;

public class MainActivity extends AppCompatActivity {
    private static final int ACTION_REQUEST_ENABLE = 1;

    // 반환되는 인텐트 정보 출력을 위한 문자열
    public static String EXTRA_DEVICE_ADDRESS = "device address";

    // 블루투스 장치 어뎁터
    private BluetoothAdapter mBtAdapter = null;

    // 장치 관리 목록 리스트
    private ArrayAdapter<String> mNewDeviceArrayAdapter;
    private ArrayAdapter<String> mPairedDeviceArrayAdapter;

    // 리스트 뷰 멤버
    ListView newDeviceListView;
    ListView pairedListView;

    // 필요 위젯 변수
    private Button scanButton = null;
    private Button btnDiscoverable = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        scanButton = findViewById(R.id.button_scan);
        btnDiscoverable = findViewById(R.id.button_discoverable);

        scanButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 검색 기능 수행
                doDiscovery();
                v.setVisibility(View.GONE);
            }
        });

        btnDiscoverable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 자신 장치의 탐색 허용 코드
                ensureDiscoverable();
            }
        });

        // ArrayAdapter 초기화
        // 1. 이미 페어링 된 장치용
        // 2. 새로 발견한 장치용
        mPairedDeviceArrayAdapter = new ArrayAdapter<String>(this, R.layout.device_name);
        mNewDeviceArrayAdapter = new ArrayAdapter<String>(this, R.layout.device_name);

        // 리스트 뷰
        pairedListView = findViewById(R.id.paired_devices);
        pairedListView.setAdapter(mPairedDeviceArrayAdapter);
        pairedListView.setOnItemClickListener(mDeviceClickListener);

        newDeviceListView = findViewById(R.id.new_devices);
        newDeviceListView.setAdapter(mNewDeviceArrayAdapter);
        newDeviceListView.setOnItemClickListener(mDeviceClickListener);

        // 로컬 블루투스 어댑터 획득!
        mBtAdapter = BluetoothAdapter.getDefaultAdapter(); // 블루투스와 관련된 모든 기능 가능!
        if(mBtAdapter == null){
            // 블루투스를 지원하지 않는 장치의 경우 처리 작업
            Toast.makeText(getApplicationContext(), "미지원 기기입니다. 앱을 종료합니다.", Toast.LENGTH_SHORT).show();
            finish(); // 현재 액티비티 자동 종료!
        }
    }

   @Override
    protected void onStart() {
        super.onStart();
        // 블루투스가 꺼져 있을 경우 활성화하도록 요청한다.
       if(!mBtAdapter.isEnabled()){
           // 블루투스 활성화 코드 on 상태로 전환
           Intent enableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
           startActivityForResult(enableIntent, ACTION_REQUEST_ENABLE); // startActivityForResult의 ACTION_REQUEST_ENABLE는 바로 위 BluetoothAdapter.ACTION_REQUEST_ENABLE와는 별개인 상수!
       }

       // BR 수신기 등록 처리
       // 장치 발견시 브로드 캐스트 리시버를 등록한다.
       IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
       registerReceiver(mReceiver, filter);

       // 검색이 완료되면 브로드 캐스트 리시버를 등록한다.
       filter = new IntentFilter(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
       registerReceiver(mReceiver, filter);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // 현재 페어링 된 장치 세트 가져와서 리스트에 추가한다.
        Set<BluetoothDevice> pairedDevices = mBtAdapter.getBondedDevices(); // 장치 세트를 가져올 수 있다.

        mPairedDeviceArrayAdapter.clear();

        // 페어링 된 장치가 있는 경우 각 장치를 ArrayAdapter 에 추가한다.
        if(pairedDevices.size() > 0){ // 페어링된 장치 목록이 있다.
            findViewById(R.id.title_paired_devices).setVisibility(View.VISIBLE);
            for(BluetoothDevice device : pairedDevices){
                mPairedDeviceArrayAdapter.add(device.getName() + "\n" + device.getAddress()); // getAddress : 장치의 MAC주소
            }
        } else{
            String noDevices = "페어링 된 장치가 없습니다.".toString();
            mPairedDeviceArrayAdapter.add(noDevices);
            // mPairedDeviceArrayAdapter.add("페어링 된 장치가 없습니다."); 와 동일
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // 장치 검색이 수행중이면 검색을 중단 시킨다.
        if(mBtAdapter != null){
            mBtAdapter.cancelDiscovery();
        }

        unregisterReceiver(mReceiver);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == RESULT_OK){
            Toast.makeText(getApplicationContext(), "블루투스 활성화 완료!", Toast.LENGTH_SHORT).show();
        } else{
            Toast.makeText(getApplicationContext(), "블루투스 활성화 실패!!! 앱을 종료합니다.", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    public void doDiscovery(){ // 내 주변에 블루투스 기기를 탐색하는 코드
        // 제목을 변경
        setTitle("장치 스캐닝 중...");

        // 새 장치의 부제목 표시
        findViewById(R.id.title_new_devices).setVisibility(View.VISIBLE);

        // 이미 장치를 발견한 경우 스캐닝 중지
        if(mBtAdapter.isDiscovering()){
            mBtAdapter.cancelDiscovery(); // 이 코드가 없으면 또 발견함!
        }

        // 블루투스 장치 검색 요청
        mBtAdapter.startDiscovery();
    }

    // 60초 동안 현재 장치의 검색을 허용한다.
    public void ensureDiscoverable(){
        if (mBtAdapter.getScanMode() != BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE){
            Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
            intent.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 60);
            startActivity(intent);
        }
    }

    private AdapterView.OnItemClickListener mDeviceClickListener = new AdapterView.OnItemClickListener() { // 리스트뷰에서 사용
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            // 연결 작업을 위해 검색을 취소한다.
            mBtAdapter.cancelDiscovery();

            // 장치이름과 MAC 주소 얻기
            String info = ((TextView)view).getText().toString();
            String address = info.substring(info.length() - 17);

            // 연결을 위한 코드 작성 필요...
            Toast.makeText(getApplicationContext(), address + "로 연결합니다.", Toast.LENGTH_SHORT).show();
        }
    }; // 이너클래스 형태, 마지막 세미콜론 필요!

    private final BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();

            // 기기 검색 상태 브로드캐스트 수신 처리
            if(BluetoothDevice.ACTION_FOUND.equals(action)){
                // Intent 에서 블루투스 장치 객체 가져오기
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                // 검색 기기의 목록 추가 작업
                // 기기 검색 목록에 없는 경우 목록에 추가한다.
                if(device.getBondState() != BluetoothDevice.BOND_BONDED){
                    mNewDeviceArrayAdapter.add(device.getName() + "\n" + device.getAddress());
                }
            }
            // 기기 검색이 완료 상태인 브로드캐스트 수신 시 처리
            else if(BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)){
                if (mNewDeviceArrayAdapter.getCount() == 0){
                    String noDevices = "검색된 장치가 없습니다.".toString();
                    setTitle(noDevices);
                    scanButton.setVisibility(View.VISIBLE);
                    mNewDeviceArrayAdapter.add(noDevices);
                } else{
                    setTitle("연결할 장치를 선택하세요!");
                }
            }
        }
    }; // 이너클래스 형태, 마지막 세미콜론 필요!
}
