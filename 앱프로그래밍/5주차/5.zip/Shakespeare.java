package com.example.homework05;

public final class Shakespeare {
    public static final String[] TITLES={
            "Henry IV(1)",
            "Henry V",
            "Henry VIII",
            "Richarrd II",
            "Richard III",
            "Merchant of Venice",
            "Othello",
            "King Lear"
    };

    public static final String[] DIALOGUE = {
            "헨리4권",
            "헨리5권",
            "헨리8권",
            "리차드2권",
            "리차드3권",
            "보이스",
            "오델로",
            "킹"
    };
}
