package com.example.homework05;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentTransaction;
import androidx.fragment.app.ListFragment;

public class TitleFragment extends ListFragment {

    boolean mDualPane;
    int mCurCheckPosition = 0;

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        //정적 배열로 목록 채우기
        setListAdapter(new ArrayAdapter<String>(getActivity(),android.R.layout.simple_list_item_activated_1,Shakespeare.TITLES));

        //세부사항을 포함한 프레임이 있는지 확인하자
        //포함된 UI 에 직접 프레그먼트화
        View detailsFrame = getActivity().findViewById(R.id.details);
        mDualPane = detailsFrame != null && detailsFrame.getVisibility() == View.VISIBLE;

        if(savedInstanceState != null){
            //확인된 위치의 마지막 상태를 복원
            mCurCheckPosition = savedInstanceState.getInt("curChoice",0);
        }

        if(getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE && mDualPane){
            getListView().setChoiceMode(ListView.CHOICE_MODE_SINGLE);
            showDetails(mCurCheckPosition);
        }
        else{
            detailsFrame.setVisibility(View.GONE);
        }
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("curChoice",mCurCheckPosition);
    }

    @Override
    public void onListItemClick(ListView l, View v, int position, long id) {
        if(getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE && mDualPane){
            showDetails(position);
        }
        else{
            Intent intent = new Intent();
            intent.setClass(getActivity(),DetailsActivity.class);
            intent.putExtra("index",mCurCheckPosition);
            startActivity(intent);
        }
    }

    /*
    현재 UI에 조각을 제자리에 표시하거나 표시되는 완전히 새로운 활동을 시작하여 선택한 항목의 세부사항을 표시하는 도우미 기능.
     */

    void showDetails(int index){
        mCurCheckPosition = index;
        DetailsFragment details;

        if(mDualPane){
            //조각으로 모든 것을 제자리에 표시할 수 있으므로 목록을 업데이트하여 선택한 항목을 강조 표시하고 데이터를 표시하십시오.
            getListView().setItemChecked(index,true);

            //현재 표시된 프래그먼트를 확인하고 필요한 경우 교체하십시오.
            details = (DetailsFragment) getFragmentManager().findFragmentById(R.id.details);
            if(details == null || details.getShownIndex() != index) {
                details = DetailsFragment.newInstance(index);

                //프래임 내에서 기존 프래그먼트를 이 조각으로 대체하여 트랜잭션을 실행하십시오.
                FragmentTransaction ft = getFragmentManager().beginTransaction();
                ft.replace(R.id.details, details);
                ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                ft.commit();
            }
        }else{
            Intent intent = new Intent();
            intent.setClass(getActivity(), DetailsActivity.class);
            intent.putExtra("index",index);
            startActivity(intent);
        }
    }

}
